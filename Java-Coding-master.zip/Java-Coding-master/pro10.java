import java.util.Scanner;
class Pro10
{
        public static void main(String [] args)
        {
                Scanner sc=new Scanner(System.in);
                int i=sc.nextInt();
                for(int j=0;j<=10;j++)
                {
                        System.out.println(i+" X "+j+" = "+i*j);
                }
        }
}

