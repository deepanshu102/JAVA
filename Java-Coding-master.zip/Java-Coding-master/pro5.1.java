class pro50
{
        public static void main(String [] args)
        {
                System.out.println("Hello World I am String array method");
		pro50.main(56);
        }
        public static void main(int arg)
        {
                System.out.println("Hello World I am Intger array method");
                String arh="hello World";
                pro50.main(arh);
        }
        public static void main(String arg)
        {
                System.out.println(arg+" I am String variable method");
        }
}
