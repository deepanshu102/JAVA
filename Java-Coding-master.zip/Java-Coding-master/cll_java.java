/*
Name:Deepanshu Gupta
Roll No:41550404417
Topic:
Questions;
*/
class Pro
{
        public static void main(String [] args)
        {
                System.out.println("Welcome to java");
        }
}
