public class pro6
{
        public static void main(String [] args)
        {
                String [] arg={"HELLO"," WORLD","HOW ARE YOU"};
                System.out.println("Hiii i am Starting point of the program");
                pro.main(arg);
        }
}
class pro
{
        public static void main(String [] args)
        {
                System.out.println(args[0]+args[1]+args[2]);
        }
}
