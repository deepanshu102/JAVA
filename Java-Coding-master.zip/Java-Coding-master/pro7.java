class pro7
{
        public static void main(String args [])
        {
                //i am using the property i.e length method
                if(args.length >1)
                {
                        for(String s:args)
                        {
                                System.out.println(s);
                        }
                }
        }
}
