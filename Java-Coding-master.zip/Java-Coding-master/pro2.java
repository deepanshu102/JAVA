class pro
{
        public static void main(String [] args)
        {
                System.out.println("Hello I am pro class main method");
        }
}
class pro2
{
        public static void main(String [] args)
        {
                System.out.println("Hello I am pro2 class main method");
		

        }
}
