class Pro11
{
        public static void main(String [] args)
        {
                char c='A',k='a';
                for(int i=0;i<26;i++)
		{
   			System.out.println(c+"\t"+(char)(c+32));                     
			c++;
		}
		
        }
}

