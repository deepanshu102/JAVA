class PRO
{
        public static void main(String [] args)
        {
                System.out.println("Hello World");
        }
}

public class PRO3
{
        public static void main(String [] args)
        {
		String []arr={"Helolo","how are you"};
                System.out.println("HEllo I am Pro3 class main method");
		PRO.main(arr);
        }
}


