public class Pro4
{
        public static void main(String []args)
        {
                System.out.println("I AM STRING ARRAY MAIN()");
        }
        public static void main(int [] args)
        {
                System.out.println("I am Integer array main()");
        }
        public static void main(String arg)
        {
                System.out.println("I am string main ()");
        }
}
